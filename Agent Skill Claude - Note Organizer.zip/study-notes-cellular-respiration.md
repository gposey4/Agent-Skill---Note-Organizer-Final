# Study Notes: Cellular Respiration
**Source:** BIO 110, Lecture 14 | **Generated from:** Pasted text

## Overview
This lecture covers how cells break down glucose with O2 to produce CO2, H2O, and ATP. Cellular respiration runs in three stages (glycolysis, the Krebs cycle, and the ETC), linked by pyruvate oxidation, with chemiosmosis producing most of the ATP. When O2 is absent, cells use fermentation instead.

## Key Terms
| Term | Definition |
|---|---|
| ATP | The product cells make from breaking down glucose. Not expanded in source. [F1] |
| glycolysis | The first stage: in the cytoplasm, glucose (6C) is split into 2 pyruvate (3C); no O2 needed. |
| Krebs cycle (citric acid cycle) | The second stage, in the mitochondrial matrix; acetyl CoA enters and NADH, FADH2, ATP, and CO2 are produced. |
| ETC | The third stage; uses NADH + FADH2 and pumps H+ across a membrane. Not expanded in source. [F2] |
| pyruvate | The 3C molecule produced when glucose is split in glycolysis. |
| NADH | Produced in glycolysis and the Krebs cycle; used by the ETC. Not defined in source. [F1] |
| acetyl CoA | The molecule pyruvate is converted to during pyruvate oxidation; it enters the Krebs cycle. |
| FADH2 | Produced in the Krebs cycle; used by the ETC. Not defined in source. [F1] |
| chemiosmosis | H+ flows back through ATP synthase, which makes most of the ATP (~32-34). |
| ATP synthase | The structure H+ flows back through during chemiosmosis to make ATP. |
| final electron acceptor | The role of O2; it forms water. |
| fermentation | What happens when there is no O2 (lactic acid in muscles, alcohol in yeast). |

## Main Concepts
### 1. Overall Process
- Overall: glucose + O2 → CO2 + H2O + **ATP** [F1].
- Three stages: **glycolysis**, **Krebs cycle** (aka **citric acid cycle**), and **ETC** [F2].
- **Exam hint:** the professor said "you WILL be asked where each stage happens."

### 2. Glycolysis
- Location: cytoplasm.
- Glucose (6C) is split into 2 **pyruvate** (3C).
- No O2 needed.
- Net gain: 4 ATP [F3] + 2 **NADH**.

### 3. Pyruvate Oxidation
- **Pyruvate** → **acetyl CoA**, releasing CO2.
- Location: mitochondria.

### 4. Krebs Cycle
- Location: mitochondrial matrix.
- **Acetyl CoA** enters.
- Produces **NADH**, **FADH2**, 2 ATP, and releases CO2.
- Remaining details were missed in the notes. [F4]

### 5. ETC and Chemiosmosis
- Location: notes say mitochondrial matrix, but a later slide says inner mitochondrial membrane. [F5]
- Uses **NADH** + **FADH2** and pumps H+ across the membrane.
- **Chemiosmosis:** H+ flows back through **ATP synthase**, making most of the ATP (~32-34).
- O2 is the **final electron acceptor** and forms water.

### 6. Without Oxygen
- No O2 → **fermentation**: lactic acid in muscles, alcohol in yeast.

## Formulas & Equations
- `glucose + O2 -> CO2 + H2O + ATP` — the overall reaction for cellular respiration (reactants on the left, products on the right); use to summarize inputs and outputs of the whole process.

## Examples & Applications
- **Muscles:** produce lactic acid through fermentation when there is no O2 — illustrates fermentation.
- **Yeast:** produce alcohol through fermentation — illustrates fermentation.

## Flagged Items
| ID | Type | Where | Issue | What to check |
|---|---|---|---|---|
| F1 | UNDEFINED TERM | Key Terms; Main Concepts > 1, 2, 4 | ATP, NADH, and FADH2 are used but never expanded or defined. | Commonly: adenosine triphosphate, and the electron carriers NADH and FADH2. Confirm definitions in the textbook. |
| F2 | UNDEFINED TERM | Key Terms; Main Concepts > 1 | ETC is never expanded. | Commonly "electron transport chain"; confirm with slides. |
| F3 | POSSIBLE ERROR | Main Concepts > 2. Glycolysis | Notes say net gain of 4 ATP from glycolysis. | Standard texts give 4 ATP gross but 2 ATP net (2 are used up). Confirm which the lecturer meant. |
| F4 | INCOMPLETE | Main Concepts > 4. Krebs Cycle | Notes say "missed the rest". | Fill in from the slides or a classmate's notes. |
| F5 | CONFLICT | Main Concepts > 5. ETC and Chemiosmosis | Notes place the ETC in the mitochondrial matrix; a later slide says the inner mitochondrial membrane. | High priority (locations are exam material): standard texts place the ETC on the inner mitochondrial membrane. Confirm with the slides. |

## Review Questions
1. Where in the cell does each stage of cellular respiration happen?
2. What goes in and what comes out of glycolysis?
3. What happens during pyruvate oxidation, and what does it produce?
4. How does chemiosmosis use ATP synthase to make most of the ATP?
5. What role does O2 play at the end of the ETC, and what happens when O2 is absent?
