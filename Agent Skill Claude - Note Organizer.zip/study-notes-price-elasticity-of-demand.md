# Study Notes: Price Elasticity of Demand
**Source:** ECON 201, Week 5 lecture (recording transcript) | **Generated from:** Pasted text

## Overview
This lecture introduces price elasticity of demand (PED), which measures how responsive quantity demanded is to a change in price. It covers how PED is calculated and classified, what determines it, and how the total revenue test links elasticity to pricing decisions. The midpoint method is introduced as a way to get consistent answers regardless of direction.

## Key Terms
| Term | Definition |
|---|---|
| Price elasticity of demand (PED) | Measures how responsive quantity demanded is to a change in price. |
| elastic | As stated in lecture: the absolute value of PED is less than one. [F1] |
| inelastic | As stated in lecture: the absolute value of PED is greater than one. [F1] |
| unit elastic | The absolute value of PED is exactly one. |
| Total revenue test | Uses elasticity to predict how a price increase changes total revenue: falls if demand is elastic, rises if inelastic. |
| midpoint method | A method that avoids getting different answers depending on direction. Formula to be posted on slides. [F3] |
| XED | Not defined in source; mentioned as "cross-price", coming next lecture. [F4] |
| YED | Not defined in source; described only as "the other one", coming next lecture. [F4] |

## Main Concepts
### 1. Price Elasticity of Demand (PED)
- **PED** measures how responsive quantity demanded is to a change in price.
- Usually discussed in terms of its absolute value.

### 2. Classifying Elasticity
- Absolute value of PED less than one → **elastic**. [F1]
- Absolute value of PED greater than one → **inelastic**. [F1]
- Absolute value of PED exactly one → **unit elastic**.

### 3. Determinants of PED
- **Availability of substitutes** ("the big one"): more substitutes → more **elastic**.
- **Necessity or luxury:** necessities tend to be **inelastic**.
- **Time horizon:** demand is more **elastic** in the long run.
- **Share of income:** mentioned; details deferred to a later lecture. [F2]

### 4. Total Revenue Test
- **Exam hint:** "this is important, this will be on the midterm."
- Demand **elastic** + price raised → total revenue falls.
- Demand **inelastic** + price raised → total revenue rises.

### 5. Midpoint Method
- Avoids the problem of getting different answers depending on direction.
- Formula not given in lecture; to be posted on the slides. [F3]

### 6. Coming Next
- Next lecture covers **XED** and **YED** ("cross-price and the other one"). [F4]

## Formulas & Equations
- `PED = %ΔQd / %ΔP` — %ΔQd is the percentage change in quantity demanded; %ΔP is the percentage change in price. Use to measure how responsive quantity demanded is to a price change.
- Midpoint method formula: not given in source. [F3]

## Examples & Applications
- **Insulin:** people with diabetes need it and there is no substitute, so demand is very inelastic — illustrates the substitutes and necessity determinants.
- **A specific brand of soda (cola):** if one cola raises its price, people switch, so demand is elastic — illustrates availability of substitutes.

## Flagged Items
| ID | Type | Where | Issue | What to check |
|---|---|---|---|---|
| F1 | POSSIBLE ERROR | Key Terms; Main Concepts > 2. Classifying Elasticity | Lecture says absolute value of PED less than one is elastic and greater than one is inelastic. This appears reversed, and it is inconsistent with the lecture's own insulin and soda examples. | Standard texts define elastic as absolute value of PED greater than 1 and inelastic as less than 1. Re-listen to the recording or confirm with the professor; this affects the total revenue test. |
| F2 | INCOMPLETE | Main Concepts > 3. Determinants of PED | Share of income is listed as a determinant but not explained. | Check later lectures or the textbook for how share of income affects PED. |
| F3 | INCOMPLETE | Key Terms; Main Concepts > 5; Formulas & Equations | Midpoint method formula was not stated; it is to be posted on the slides. | Copy the formula from the slides into these notes. |
| F4 | UNDEFINED TERM | Key Terms; Main Concepts > 6 | XED and YED are named but not defined; YED is only called "the other one". | Commonly cross-price elasticity of demand and income elasticity of demand; confirm next lecture. |

## Review Questions
1. What does PED measure, and how is it calculated?
2. What are the four determinants of PED mentioned in the lecture?
3. Why is demand for insulin very inelastic while demand for a specific brand of soda is elastic?
4. According to the total revenue test, what happens to total revenue when price rises under elastic and under inelastic demand?
5. What problem does the midpoint method solve?
